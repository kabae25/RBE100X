import dijkstra_class
import main
import time


class State():
    START = 0
    PATH_GEN = 1
    EXECUTING = 2
    END = 3

class Move():
    def turn_left(self):
        print('left_turn()')
        time.delay(0.5)
        
    def turn_right(self):
        print('turn_right()')
        time.delay(0.5)
        
    def move_forward(self):
        print('move_forward()')
        time.delay(0.5)

class Finite_State_Machine():
    def __init__(self):
        self.current_state = State.START
        self.end_states = [State.END]
        self.path_index = 1
        self.instruction_set = []
        self.task()

    def task(self):
        while self.current_state not in self.end_states:
            # This will run until an end state is reached
            #print(self.current_state)
            # if <something>:
                #self.current_state = self.on_event(cargo) 
            
            self.on_event()

    def on_event(self):
        match self.current_state:
            case State.START:
                return self.__START_handler()
            case State.PATH_GEN:
                return self.__PATH_GEN_handler()
            case State.EXECUTING:
                return self.__EXECUTING_handler()
            case State.END:
                return self.__END_handler()
            
    def __START_handler(self):
        self.current_state = State.PATH_GEN
        

    def __PATH_GEN_handler(self): 
        if self.path_index > len(main.paths): # this line prevents an error associated with no paths being present
            self.current_state = State.END
        else:
            print('Path',self.path_index)
            dijkstra_object = dijkstra_class.Dijkstra(tuple(main.paths[self.path_index]["Source Node"]), main.paths[self.path_index]["Destination Node"], tuple(main.paths[self.path_index]["Obscured Nodes"]))
            self.instruction_set = dijkstra_object.shortest_path()

            self.current_state = State.EXECUTING

    def __EXECUTING_handler(self):
        self.path_index+=1

        print(self.instruction_set)
        for i in range(0, len(self.instruction_set)): # should be 0 - 8
            #print(i, len(self.instruction_set)-1)
            if not(i == len(self.instruction_set)-1):
                #print('iterating')
                #print(self.instruction_set[i])
                #print('Current Node',self.instruction_set[i])
                dx = (self.instruction_set[i+1][0]) - (self.instruction_set[i][0])
                if dx == 1:
                    print('dX: 1')
                if dx == -1:
                    print('dX: -1')
                dy = (self.instruction_set[i+1][1]) - (self.instruction_set[i][1])
                if dy == 1:
                    print('dY: 1')
                if dy == -1:
                    print('dY: -1')

        #print(self.instruction_set[0][0])






        self.instruction_set = []
        self.current_state = State.PATH_GEN

    def __END_handler(self):
        pass

finite_state_machine = Finite_State_Machine()